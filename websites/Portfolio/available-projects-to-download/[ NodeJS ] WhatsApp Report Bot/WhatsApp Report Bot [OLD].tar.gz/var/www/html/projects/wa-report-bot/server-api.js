require("dotenv").config();
const { Client, Intents, WebhookClient } = require("discord.js");
const { createPool } = require("mysql");
const geoCountry = require("geoip-country");
var countries = require("i18n-iso-countries");
const utf8 = require("utf8");
const ex = require("express");
const fs = require("fs");
const app = ex();
let port = 1111;
const client = new Client({
  intents: [Intents.FLAGS.GUILDS, Intents.FLAGS.GUILD_MEMBERS],
  partials: ["MESSAGE", "CHANNEL"],
  ws: ["GUILDS", "GUILD_MEMBERS"],
});
//======================[VARIABLES REGISTERING]=====================\\

let MCLogWebhook;
let MCVPNLogWebhook;
let MCCommandsLogWebhook;
let MCCommandsConsoleLog;

//====================[CREATING MYSQL CONNECTION]===================\\
let con = createPool({
  host: process.env.HOST,
  user: process.env.USER,
  password: process.env.PASSWORD,
  database: process.env.DATABASE,
  connectionLimit: 10,
});
async function execute(con, sql, arr = []) {
  return new Promise((res, rej) => {
    con.query(sql, arr, (err, rs, ff) => {
      //console.log(err, rs);
      if (err || rs.length <= 0) return res([]);
      return res(rs);
    });
  });
}
//==================================================================\\
client.on("ready", () => {
  MCLogWebhook = new WebhookClient({
    url: "https://discord.com/api/webhooks/986144121158762567/LWtsYxeMqzIwqSsnJFu3DfnopRWA8s1O2tePXNRXUqRHD0sLaTCKU1S3paqzGZDkOkl6",
  });
  MCCommandsLogWebhook = new WebhookClient({
    url: "https://discord.com/api/webhooks/986145010468675584/ngF5DQNDqZkWjdaZNw1ZXzz9z2fVOlArMTHqyv5SYpNNjrnQ0f8u5rW3tm0pRtjvwLbz",
  });
  MCCommandsConsoleLog = new WebhookClient({
    url: "https://discord.com/api/webhooks/975471019097718856/me1BUsJVQtpfHbbn1hG_xzrNCpe7ef09OXfcULqo-6AMYvB8mWqQnH8SALH9zeJXV7D-",
  });
  MCVPNLogWebhook = new WebhookClient({
    url: "https://discord.com/api/webhooks/987142988058730526/cCTGy8KPoAeckjg5cN71AyN9lMpnCcsidGnP2ahWM9ZUuEhsiYtx5U01mYu8Va5goSVP",
  });
});

async function save_player(uuid, discordUsername, ip, country) {
  await execute(
    con,
    `UPDATE \`login\` set ip='${ip}', country='${country}' where uuid='${uuid}'`,
    []
  );
  try {
    await execute(
      con,
      `UPDATE \`players\` set discordUsername='${utf8.encode(
        discordUsername == null ? "null" : discordUsername
      )}' where uuid='${uuid}'`,
      []
    );
  } catch (e) {}
}
//==================================================================\\

app.use((req, res, next) => {
  let slt = req.ip.split(":");
  req.address = slt[slt.length - 1];
  next();
});
app.get("/getuser/:uuid/:discordCode/:ip", async (req, res) => {
  //if (req.address != "127.0.0.1") return res.status(200).send("page not found.")
  let uuid = req.params.uuid;
  let discordCode = req.params.discordCode;
  let ip =
    uuid == "cedfe0fc-c76e-4e79-956d-a4ebfea24e0c"
      ? "195.242.188.247"
      : req.params.ip;
  let u = await client.guilds.cache.get("984777394546171934")?.members?.fetch();
  let country = geoCountry.lookup(ip)?.country || "SA";
  let discordUsername = u ? u?.get(discordCode)?.user?.tag : null;
  console.log(
    `saving :: ${uuid} :: [${discordCode},'${discordUsername}'] :: [${ip},'${country}']`
  );
  await save_player(uuid, discordUsername, ip, country);
  return res.sendStatus(200);
});
app.get("/sendlogmessage", (req, res) => {
  // if (req.address != "127.0.0.1") return res.status(200).send("page not found.");
  let msg = req.query.msg;
  let asd = msg.startsWith("/") ? MCCommandsLogWebhook : MCLogWebhook;
  if (!asd) return res.sendStatus(200);
  let player = req.query.player;
  player = player.length == 2 ? player[1] : player;
  msg = msg.replace("@", "`@`");
  asd.send(
    `**[${req.query.server}] ${
      req.query.rank[1] == null ? "default" : req.query.rank[1]
    } \`${player}\` » **${msg}`
  );
  return res.sendStatus(200);
});
app.get("/addrole/:userId/:roleId", async (req, res) => {
  // if (req.address != "127.0.0.1") return res.status(200).send("page not found.");
  let id = req.params.userId;
  let roleId = req.params.roleId;
  if (id == null || roleId == null) return res.sendStatus(200);
  let g = client.guilds.cache.get("984777394546171934");
  let u = await g?.members?.fetch();
  let user = u ? u?.get(id)?.user : null;
  if (user == null) return res.sendStatus(200);
  try {
    let r = await g?.roles?.fetch();
    let role = r.get(roleId);
    let m = g.members?.cache?.get(user?.id);
    if (!role || !m) return res.sendStatus(200);
    m?.roles?.add(role);
    console.log("role added to user " + user?.tag);
  } catch (error) {
    console.log(
      "error ecoured while fetching role " + roleId + " for user " + user?.tag
    );
  }
  return res.sendStatus(200);
});

app.get("/removerole/:userId/:roleId", async (req, res) => {
  // if (req.address != "127.0.0.1") return res.status(200).send("page not found.");
  let id = req.params.userId;
  let roleId = req.params.roleId;
  if (id == null || roleId == null) return res.sendStatus(200);
  let g = client.guilds.cache.get("984777394546171934");
  let u = await g?.members?.fetch();
  let user = u ? u?.get(id)?.user : null;
  if (user == null) return res.sendStatus(200);
  try {
    let r = await g?.roles?.fetch();
    let role = r.get(roleId);
    let m = g.members?.cache?.get(user?.id);
    if (!role || !m) return res.sendStatus(200);
    if (m?.roles?.cache.some((rId) => rId.id == roleId)) m?.roles?.remove(role);
    console.log("role removed from user " + user?.tag);
  } catch (error) {
    console.log(
      "error ecoured while fetching role " + roleId + " for user " + user?.tag
    );
  }
  return res.sendStatus(200);
});

app.get("/sendvpnlogmessage", (req, res) => {
  // if (req.address != "127.0.0.1") return res.status(200).send("page not found.");
  let asd = MCVPNLogWebhook;
  if (!asd) return res.sendStatus(200);
  let player = req.query.player;
  player = player.length == 2 ? player[1] : player;
  asd.send(
    `Using VPN : \`YES\` / IGN: \`${player}\` / IP: \`${
      req.query.ip[1]
    }\` / Country: \`${countries.getName(
      geoCountry.lookup(req.query.ip[1])?.country || "SA",
      "en",
      { select: "official" }
    )}\``
  );
  return res.sendStatus(200);
});

app.get("/mysqlsearch", async (req, res) => {
  let searchWith = req.query.searchWith;
  if (!searchWith) return res.send([]);
  return res.send(
    await execute(
      con,
      `select * from \`${req.query.table}\` where ${searchWith}`
    )
  );
});

app.get("/sendconsoleLogMessage", (req, res) => {
  // if (req.address != "127.0.0.1") return res.status(200).send("page not found.");
  let msg = req.query.msg;
  msg = msg.replace("@", "`@`");
  try {
    if (MCCommandsConsoleLog != null) MCCommandsConsoleLog.send(msg);
  } catch (error) {}
  return res.sendStatus(200);
});

app.get("/createFile", async (req, res) => {
  let report = req.query.report;
  if (!report) return res.sendStatus(404);
  report = decodeURI(report).replaceAll(" ", "-");
  let rs = await execute(
    customPasteCon,
    `select * from pastes where title='${report}'`,
    []
  );
  let content = rs.length ? rs[0]["content"] : null;
  console.log(content);
  if (!content) return res.sendStatus(404);
  createFileWithContent(report, content.replaceAll("/##/", "'"));
  return res.sendStatus(200);
});

//=====================[START LESTINGING]====================\\
client.login(process.env.TOKEN);
app.listen(port, console.log("Listening on " + port));
//===========================================================\\
let customPasteCon = createPool({
  host: process.env.HOST,
  user: process.env.USER,
  password: process.env.PASSWORD,
  database: "CustomPaste",
  connectionLimit: 10,
});
function createFileWithContent(report, content) {
  fs.open(`/var/www/html/${report}`, "w", function (err, file) {
    if (err) throw err;
    fs.writeFile(`/var/www/html/${report}`, content, (errr) => {
      if (errr) throw errr;
    });
    return file;
  });
}
