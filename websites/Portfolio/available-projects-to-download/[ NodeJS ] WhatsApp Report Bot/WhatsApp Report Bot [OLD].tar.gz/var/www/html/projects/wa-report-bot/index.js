require("dotenv").config();
const { Client } = require("whatsapp-web.js");
const qrcode = require("qrcode-terminal");
const wiki = require("wikipedia");
const client = new Client();
const fs = require("fs");
const app = require("express")();
const http = require("http");
const mysql = require("mysql");

//=============================
const port = 1111;
const version = "1.0";
const prefix = "!";
const devId = "01143265444";
const serverURL = process.env.HOST;
//=============================
checkIfFolderExists();
let con = mysql.createConnection(
    `mysql://${process.env.USER}:${process.env.PASSWORD}@${process.env.HOST}/${process.env.DATABASE}?charset=utf8_general_ci&timezone=-0700`
);
async function execute(sql, arr = []) {
    return new Promise((res, rej) => {
        con.query(sql, arr, (err, rs, ff) => {
            // console.log(err, rs);
            if (err || rs.length <= 0) return res([]);
            return res(rs);
        });
    });
}
//=============================

client.on("qr", (qr) => {
    qrcode.generate(qr);
});

client.on("ready", async () => {
    console.log("bot is ready!");
    const chats = await client.getChats();
    console.log(`WhatsApp API connected.`);
    console.log(`Loaded ${chats.length} chats from whatsapp API`);
    sendMessageToUser(devId, "Connected!", false);
});

client.on("message", async (msg) => {
    try {
        let _args = msg.body.split(/ +/g);
        let args = _args.slice(1);
        let cmd = _args[0].slice(prefix.length).toLowerCase();
        if (cmd == "help")
            return client.sendMessage(msg.from, getHelpMessage());
        if (cmd == "spam") {
            if (!msg.id.remote.includes(devId))
                return msg.reply(
                    `This command is currently not allowed for normal users.`
                );
            if (args.length < 4)
                return client.sendMessage(msg.from, getHelpMessage());
            let type = args[0].toLowerCase() == "group" ? "@g.us" : "@c.us";
            let message = "";
            if (args[1].charAt(0) != "2" && type == "@c.us")
                args[1] = "2" + args[1];
            for (var a in args)
                message +=
                    a >= 3 ? args[a] + (a != args.length - 1 ? " " : "") : "";
            let amount = 50;
            try {
                amount = parseInt(args[2]);
            } catch (error) {
                amount = 50;
            }
            for (let i = 0; i < amount; i++) {
                try {
                    client.sendMessage(
                        args[1] + type,
                        message.replace("{num}", i + "")
                    );
                } catch (error) {}
            }
            return client.sendMessage(
                msg.from,
                `Spam started on user [${args[1]}] ${amount} times.`
            );
        }
        if (cmd == "send") {
            if (!msg.id.remote.includes(devId))
                return msg.reply(
                    `This command is currently not allowed for normal users.`
                );
            if (args.length < 3)
                return client.sendMessage(msg.from, getHelpMessage());
            let message = "";
            let type = args[0].toLowerCase() == "group" ? "@g.us" : "@c.us";
            if (args[1].charAt(0) != "2" && type == "@c.us")
                args[1] = "2" + args[1];
            for (var a in args)
                message +=
                    a >= 2 ? args[a] + (a != args.length - 1 ? " " : "") : "";
            try {
                client.sendMessage(
                    args[1].includes(type) ? args[1] : args[1] + type,
                    message
                );
            } catch (error) {
                client.sendMessage(
                    message.from,
                    `This user does not exist. or error eccoured while sending this message.`
                );
            }
        }
        if (cmd == "report") {
            let report = args.join(" ");
            let time = new Date().getTime();
            client.sendMessage(
                msg.from,
                `Please wait while searching for a proper report.`
            );
            try {
                var page = await wiki.page(report);
                var content = await page.content();
                var images = await page.images();
                await createCustomPaste(
                    report,
                    content,
                    msg,
                    page,
                    images,
                    time
                );
                createFileWithContent(report, randomID(), content);
            } catch (error) {
                console.log(error);
                client.sendMessage(
                    msg.from,
                    `Could not find the topic (*${report}*) in wikipedia.`
                );
            }
        }
        if (cmd == "!!!" && msg.id.remote.includes(`@g.us`))
            return client.sendMessage(msg.author, getHelpMessage());
    } catch (error) {
        console.log(`error eccoured`);
        console.error(error);
    }
});

function createFileWithContent(report, id = randomID(), content) {
    fs.open(`reports/${report}-${id}.txt`, "w", function (err, file) {
        if (err) throw err;
        fs.writeFile(`reports/${report}-${id}.txt`, content, (errr) => {
            if (errr) throw errr;
        });
        return file;
    });
}

function randomID() {
    return Math.random().toString(36).substr(2, 9);
}

function getHelpMessage() {
    return `Available commands of version [${version}]:\n*1-* ${prefix}spam [group/ private] [chat-id] [number-of-times] [message] - *Under development*\n*2-* ${prefix}send [group/ private] [chat-id] [message] - *Under development*\n*3-* ${prefix}report <title> - *Available*`;
}

function checkIfFolderExists() {
    if (!fs.existsSync("reports/")) fs.mkdirSync("reports/");
}

async function createCustomPaste(report, content, msg, page, images, time) {
    let id = randomID();
    await postReportToMySQL(report.replaceAll(" ", "-") + "_" + id, content);
    http.request(
        {
            hostname: serverURL,
            port: 1111,
            path: `/createFile?report=${encodeURI(report + "_" + id)}`,
            method: "GET",
        },
        (res) => {
            if (res.statusCode != 200)
                return client.sendMessage(
                    msg.from,
                    `Could not find the topic (*${report}*) in wikipedia.`
                );
            let url = `http://reportbot.ml/${report.replaceAll(
                " ",
                "-"
            )}_${id}`;
            console.log(url);
            let urls = "";
            if (images.length > 0)
                for (var a in images)
                    urls +=
                        a < 10
                            ? `*${parseInt(a) + 1}-* ${images[a].url}` +
                              (a != images.length - 1 ? "\n" : "")
                            : "";
            client.sendMessage(
                msg.from,
                `Successfully done in ${
                    (new Date().getTime() - time) / 1000
                }seconds, here a direct link to your report text content:
          \n${url}\n\nHere's a direct link to a wikipedia website that got the report from:
        \n${page.fullurl}${
                    images.length > 0
                        ? `\n\nHere's a direct link to some photos that might help:\n\n${urls}`
                        : ""
                }`
            );
        }
    )
        .on("error", (err) => {
            client.sendMessage(
                msg.from,
                `Could not find the topic (*${report}*) in wikipedia.`
            );
            console.error(err);
        })
        .end();
}

function sendMessageToUser(user, message, bool = true) {
    try {
        if (client)
            client.sendMessage(
                (user.charAt(0) == "2" ? user : "2" + user) + "@c.us",
                message
            );
        if (bool) console.log(`sent '${message}' to '${user}' from JavaBotAPI`);
    } catch (error) {
        console.log(`Error while trying to send a whatsapp message.`);
        console.error(error);
    }
}

//================================================= [EXPREES SERVER EVENTS]

app.get("/whatsapp", (req, res) => {
    console.log(req.query);
    sendMessageToUser(req.query.id, req.query.msg);
    return res.sendStatus(200);
});

//================================================= [MYSQL FUNCTIONS]

async function postReportToMySQL(report, content) {
    await execute(
        `insert into \`pastes\` (\`title\`, \`content\`) values('${report}', '${content.replaceAll(
            "'",
            "/##/"
        )}')`
    );
}

//=========================================================================

client.initialize();
app.listen(port, console.log("Server listening on " + port));
