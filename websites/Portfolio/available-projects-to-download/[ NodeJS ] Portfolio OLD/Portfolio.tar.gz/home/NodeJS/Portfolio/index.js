const express = require(`express`);
const path = require("path");
const fs = require("fs");
const { stringify } = require("querystring");
const app = new express();
const port = 80;
const host = "dev-adly.tk";

//=============================== [SOCIAL MEDIAS]
const discordLink = "https://discord.gg/pNdECB3zVm";
const instagramLink = "https://instagram.com/mostafa.adly.amar";
const githubLink = "https://github.com/MostafaAdly";
const profilePicture = "/views/images/profilePicture.png";
//=============================== [VARIABLES]
let files;
//========================================

app.use(express.static(path.join(__dirname, "/")));
app.set("view engine", "hbs");

refreshProjects();
setInterval(() => {
    refreshProjects();
}, 1000 * 60 * 60);

//================================ [PAGES]
app.get(`/`, (req, res) => {
    res.render("index", {
        page: "Home - Portfolio",
        name: "Mostafa Adly",
        city: "Egypt, Giza",
        age: "20",
        media: [
            {
                name: "DISCORD",
                link: `http://${host}/discord`,
                picture: `/views/images/discord.svg`,
            },
            {
                name: "INSTAGRAM",
                link: `http://${host}/instagram`,
                picture: `/views/images/instagram.svg`,
            },
            {
                name: "GITHUB",
                link: `http://${host}/github`,
                picture: `/views/images/github.svg`,
            },
        ],
        pfp: profilePicture,
    });
});

app.get("/discord", (req, res) => {
    res.status(301).redirect(discordLink);
});

app.get("/instagram", (req, res) => {
    res.status(301).redirect(instagramLink);
});

app.get("/github", (req, res) => {
    res.status(301).redirect(githubLink);
});
app.get("/projects", (req, res) => {
    res.render("projects", {
        page: "Home - Portfolio",
        name: "Mostafa Adly",
        pfp: profilePicture,
        filesList: files,
    });
});
app.get("*", (req, res) => {
    res.status(301).redirect("/");
});
//========================================
function getFirstNDigitsAfterDot(num, digits) {
    num = `${num}`;
    return num == null || num == 0 || digits <= 0
        ? num
        : Number(num.split(".")[0]) +
              Number("0." + num.split(".")[1].slice(0, digits));
}
function refreshProjects() {
    fs.readdir(`${__dirname}/available-projects-to-download`, (err, f) => {
        if (err) return console.log("unable to see directory {/}");
        files = [];
        for (var a in f) {
            let fileSize =
                fs.statSync(
                    `${__dirname}/available-projects-to-download/${f[a]}`
                )["size"] / 1024;
            fileSize = `${
                fileSize > 1000
                    ? getFirstNDigitsAfterDot(fileSize / 1024, 2) + ` MB`
                    : getFirstNDigitsAfterDot(fileSize, 2) + ` KB`
            }`;
            files.push({
                name: f[a].replace(".tar.gz", ""),
                size: fileSize,
            });
        }
        console.log(files);
        console.log(
            `Projects list refreshed: ${
                !files ? 0 : files.length
            } projects available`
        );
    });
}
//========================================

app.listen(port, console.log(`Listening in ${port}`));
